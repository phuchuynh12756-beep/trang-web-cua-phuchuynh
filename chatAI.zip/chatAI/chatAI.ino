import cv2
import numpy as np

# Đường dẫn video Bad Apple
video_path = "bad_apple.mp4"
cap = cv2.VideoCapture(video_path)

frames = []
frame_count = 0

while cap.isOpened():
    ret, frame = cap.read()
    if not ret or frame_count > 400: # Lấy tối đa 400 khung hình
        break

    # Giảm fps (lấy 1/2 số khung)
    if frame_count % 2 == 0:
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        resized = cv2.resize(gray, (128, 64))
        _, bw = cv2.threshold(resized, 128, 255, cv2.THRESH_BINARY)

        # Chuyển đổi ảnh đen trắng thành dạng byte bitmap (Monochrome)
        bytes_data = []
        for y in range(64):
            for x in range(0, 128, 8):
                byte = 0
                for bit in range(8):
                    if bw[y, x + bit] > 0:
                        byte |= (1 << (7 - bit))
                bytes_data.append(f"0x{byte:02x}")
        frames.append(", ".join(bytes_data))

    frame_count += 1

cap.release()

# Ghi ra file header bad_apple_data.h
with open("bad_apple_data.h", "w") as f:
    f.write("#include <pgmspace.h>\n\n")
    f.write(f"const unsigned char PROGMEM bad_apple_frames[{len(frames)}][1024] = {{\n")
    for frame_str in frames:
        f.write(f"  {{{frame_str}}},\n")
    f.write("};\n")

print(f"Da xuat {len(frames)} khung hinh sang file bad_apple_data.h thành công!")