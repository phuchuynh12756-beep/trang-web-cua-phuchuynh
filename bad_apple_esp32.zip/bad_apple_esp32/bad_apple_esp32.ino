#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include "bad_apple_rle.h"

// Cấu hình màn hình
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET    -1
#define SCREEN_ADDRESS 0x3C

// Cấu hình chân ESP32-C3 của bạn
#define PIN_BUTTON 4
#define PIN_SCL    5
#define PIN_SDA    6

#define TARGET_FPS 15
#define FRAME_DELAY_MS (1000 / TARGET_FPS)

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// Bộ đệm chứa 1 frame sau khi giải nén (128 x 64 / 8 = 1024 bytes)
uint8_t frameBuffer[1024];

bool isPaused = false;
bool lastButtonState = HIGH;

// Hàm giải nén thuật toán RLE ra RAM
void decompressRLE(const uint8_t* rleData, uint16_t dataSize) {
  uint16_t bufferIdx = 0;
  for (uint16_t i = 0; i < dataSize; i += 2) {
    uint8_t count = pgm_read_byte(rleData + i);
    uint8_t value = pgm_read_byte(rleData + i + 1);
    while (count-- > 0 && bufferIdx < 1024) {
      frameBuffer[bufferIdx++] = value;
    }
  }
}

void setup() {
  Serial.begin(115200);

  // Cấu hình Nút nhấn (GPIO 4)
  pinMode(PIN_BUTTON, INPUT_PULLUP);

  // Khởi tạo I2C trên chân GPIO 6 (SDA) và GPIO 5 (SCL)
  Wire.begin(PIN_SDA, PIN_SCL);
  Wire.setClock(800000); // Ép xung I2C lên 800kHz để mượt hình

  if (!display.begin(SSD1306_SWITCHCAPVCC, SCREEN_ADDRESS)) {
    Serial.println(F("Khong tim thay OLED SSD1306!"));
    for (;;);
  }

  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);
  display.setCursor(25, 25);
  display.println(F("BAD APPLE!!"));
  display.display();
  delay(1000);
}

void loop() {
  for (int i = 0; i < TOTAL_FRAMES; i++) {
    unsigned long frameStart = millis();

    // Xử lý nút nhấn Tạm dừng / Tiếp tục
    bool currentButtonState = digitalRead(PIN_BUTTON);
    if (lastButtonState == HIGH && currentButtonState == LOW) {
      isPaused = !isPaused;
      delay(50); // Chống dội phím
    }
    lastButtonState = currentButtonState;

    // Vòng lặp chờ khi bấm tạm dừng
    while (isPaused) {
      if (digitalRead(PIN_BUTTON) == LOW) {
        isPaused = false;
        delay(200);
        break;
      }
      delay(10);
    }

    // Đọc địa chỉ và độ dài frame nén từ Flash
    const uint8_t* ptr = (const uint8_t*)pgm_read_ptr(&(bad_apple_frames[i]));
    uint16_t size = pgm_read_word(&(frame_sizes[i]));

    // Giải nén frame hiện tại
    decompressRLE(ptr, size);

    // Vẽ và đẩy ra OLED
    display.clearDisplay();
    display.drawBitmap(0, 0, frameBuffer, SCREEN_WIDTH, SCREEN_HEIGHT, SSD1306_WHITE);
    display.display();

    // Đồng bộ thời gian để giữ FPS chuẩn
    unsigned long frameTime = millis() - frameStart;
    if (frameTime < FRAME_DELAY_MS) {
      delay(FRAME_DELAY_MS - frameTime);
    }
  }
}